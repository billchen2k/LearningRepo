

# Duck Hunt

> East China Normal University  
> 10185101210 陈俊潼

![image-20201213202546722](https://billc.oss-cn-shanghai.aliyuncs.com/img/2020-12-13-22Ky1N.png)

A simple duck hunt game as a demonstration of basic design pattern of OOAD.

Click to shoot ducks. Each duck will fly away in 15 seconds, so be quick.

Main Class Diagram:

![duckhuntuml](https://billc.oss-cn-shanghai.aliyuncs.com/img/2020-12-14-1kUnPh.png)

---

Written in java Swing. Image assets are obtained from `ShutterStock`, all rights reserved.