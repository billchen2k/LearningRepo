package io.billc.duckhunt.FlyBehaviour;

import io.billc.duckhunt.Ducks.Duck;

/**
 * @author billchen
 * @version 1.0
 * @create 2020-12-12 20:29
 **/
public interface FlyBehaviourInterface {
	public abstract Duck fly(Duck duck);
}
