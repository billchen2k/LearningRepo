import io.billc.duckhunt.Utils.Utils;
import org.junit.jupiter.api.Test;

/**
 * @author billchen
 * @version 1.0
 * @create 2020-12-13 18:27
 **/
public class FontTest {

	@Test
	public void fontTest(){
		Utils.getFont("superhelio.ttf", 24);
	}
}
