package io.billc.duckhunt.QuackBehaviour;

/**
 * @author billchen
 * @version 1.0
 * @create 2020-12-12 20:29
 **/
public interface QuackBehaviourInterface {
	public abstract void quack();

	public abstract boolean isQuacking();
}
