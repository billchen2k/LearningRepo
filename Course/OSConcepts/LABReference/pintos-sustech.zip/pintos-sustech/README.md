# operating system project2
CS302, SUSTech

-----------------------------------------------------
Project 2: User Program

## Project member
* DNXie [@DNXie](https://github.com/DNXie)
* Liziwl [@liziwl](https://github.com/liziwl)

## Project report
* [Project2 Finial report](./report/project2.md)

## Project details must be mentioned
This SUSTech pintos project 2 is almost the same as its original ones in Stanford or Berkeley. But the simulator we use is Bochs instead of QEMU.

## Completeness
PASS all test cases except multi-oom. We add 2 custom test case for user program. You can look for the detail in the report.
