## Python 基础作业 X

预计耗时约 5 min。

### 需要了解

- 使用 GitHub 协作代码。
- 了解 GitHub Desktop 的使用方法。

### 要求

- 安装配置 Git 环境。（直接安装 GitHub Desktop 也可）
- 注册一个 GitHub 账号，并新建一个名为 python-basis-work 的仓库。
- 使用 GitHub Desktop 或命令行界面，将 Work 0 - 4 的代码上传到该仓库中。
